
from django.db.models.signals import post_save
from django.dispatch import receiver
from .documents import PostDocument
from .models import Post

@receiver(post_save, sender=Post)
def index_post(sender, instance, **kwargs):
    # Connect this signal to the update_index method of the PostDocument
    post_document = PostDocument()
    post_document.update_index(instance)
