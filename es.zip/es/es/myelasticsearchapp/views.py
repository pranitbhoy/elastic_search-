from django.shortcuts import render
from django_elasticsearch_dsl.search import Search
from .documents import PostDocument

def home(request):
    return render(request, 'index.html')

def search_results(request):
    if request.method == 'POST':
        search_query = request.POST.get('search', '')
        print(f"Search query: {search_query}")

        s = Search(index='posts_index').query("multi_match", query=search_query, fields=['title^3', 'summary', 'link'])
        response = s.execute()

        hits = response.hits

        context = {'hits': hits, 'search_query': search_query}
        return render(request, 'search_results.html', context)

    return render(request, 'index.html')
