
#documents.py
# from django_elasticsearch_dsl import Document, fields
# from .models import Post
#
# class PostDocument(Document):
#     class Index:
#         name = 'posts_index'
#         settings = {'number_of_shards': 1, 'number_of_replicas': 1}
#
#     title = fields.TextField(attr='title')
#     summary = fields.TextField(attr='summary')
#     link = fields.KeywordField(attr='link')
#
#     class Django:
#         model = Post



from django_elasticsearch_dsl import Document, Index, fields
from .models import Post

post_index = Index('posts_index')

@post_index.doc_type
class PostDocument(Document):
    title = fields.TextField()
    summary = fields.TextField()
    link = fields.KeywordField()

    class Django:
        model = Post

    def update_index(self, instance, **kwargs):
        # Index the post instance
        self.update(instance)

